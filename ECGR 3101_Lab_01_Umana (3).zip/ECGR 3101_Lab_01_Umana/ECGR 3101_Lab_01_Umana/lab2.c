#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_types.h"
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "driverlib/gpio.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "buttons.h"

int X;
int Switch;

void mydelay(void)
{
uint8_t Del;
while(X < 20)
{
uint8_t Stat = ButtonsPoll(&Del, 0);
if(BUTTON_PRESSED(LEFT_BUTTON, Stat, Del)) //Switch 1
{
Switch = 1;
}
else if (BUTTON_PRESSED(RIGHT_BUTTON, Stat, Del)) // Switch 2
{
Switch = 2;
}
}
X = 0;
}

void SysTickX(void)
{
X++;
}

int
main(void){
//set the GPIO direction
SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);
//set the clock frequency to 80 MHz
SysCtlClockSet(SYSCTL_SYSDIV_2_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);
//enable the port for the red and green LEDs
GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1);// RED LED
GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_3);// GREEN LED
//set up the switches (using calls to button.c)
ButtonsInit();
//set SysTick RELOAD value for a 0.2 s delay
SysTickPeriodSet(16000000);// Got from 80Hz/0.2s
//enable the SysTick peripheral
SysTickIntRegister(SysTickX);
SysTickEnable();

//create a while(1) do-forever loop
while(1)
{
//turn off all of the LEDs
GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0X0); // RED LED OFF
GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0X0); // GREEN LED OFF
mydelay();
switch(Switch)
{
//turn on the current LED color
case 1:
GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_PIN_1); // RED LED ON
break;
// turn on the current LED color
case 2:
GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3); // GREEN LED ON
break;
}
//delay for 4 seconds
mydelay();
}
}
